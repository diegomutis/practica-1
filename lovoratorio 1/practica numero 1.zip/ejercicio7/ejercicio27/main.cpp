/*
Ejercicio 27.
Escriba un programa que actúe como una calculadora con operaciones de suma, resta, multiplicación y división, el usuario debe ingresar los operandos y la operación a realizar.
Ej: si se ingresan 3, + y 5 se debe imprimir: 3+5=8
*/


#include <iostream>

using namespace std;

int main()
{

    int numero1;
    int numero2;
    char operador;
    cout << "Ingrece un numero"<< endl;
    cin >>numero1;
    cout<< "Ingrece otro numero"<<endl;
    cin>> numero2;
    cout<<"Ingrece el operador + - * / "<<endl;
    cin>>operador;

    if (operador=='+'){ // control de fujo para determinar que operacion se deve realizar
        int suma = numero1+numero2;
        cout <<numero1<<"+"<<numero2<<" = "<<suma<<endl;
    }
    if (operador=='-'){ // control de fujo para determinar que operacion se deve realizar
        int resta = numero1-numero2;
        cout <<numero1<< "-"<< numero2<< " = "<< resta<< endl;

    }
    if (operador=='*'){ // control de fujo para determinar que operacion se deve realizar
        int multiplicacion = numero1*numero2;
        cout <<numero1<<"*"<<numero2<<" = "<<multiplicacion<< endl;

    }
    if (operador=='/'){ // control de fujo para determinar que operacion se deve realizar
        int divicion = numero1/numero2;
        cout<<numero1<<"/"<<numero2<<" = "<<divicion<<endl;
    }

    return 0;
}
