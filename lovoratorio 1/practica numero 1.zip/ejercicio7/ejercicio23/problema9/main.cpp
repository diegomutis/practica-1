/*
Problema 9.
Escriba un programa que pida un número entero N e imprima el resultado de la suma de todos sus dígitos elevados a sí mismos.
Ej: si se ingresa 1223 el resultado sería 11 + 22 + 22 + 33 = 36 Nota: la salida del programa debe ser:
    El resultado de la suma es: 36.
*/

#include <iostream>

using namespace std;

int main()
{


 int numero;
 int y;
 int suma = 0;
 cout<< "ingrece un numero ";
 cin >>numero;
 while (numero > 0) { // siclo para determinar los dijitos de dicho numero
     y =numero%10;
     numero = numero/10;
     int primero =1;
     for (int i=1;i<=y;i++){ // siclo para realizar los cuadrados de los numeros
         primero=primero*y;

     }
     suma =primero+suma;

     cout << y<<"^"<<y<<" + "; // cout para ir imprimiendo en pantalla los cuadrados

 }
 cout<< " = "<< suma <<endl ; // para imprimir en pantalla la suma de los cuadrados
   return 0;
}
