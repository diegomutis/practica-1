/*
Ejercicio 7.
Escriba un programa que pida un número N e imprima en pantalla la suma de todos los números entre 0 y N (incluyéndose el mismo).
Ej: si se ingresa 5: 1+2+3+4+5=15, por lo que se debe imprimir: La sumatoria desde 0 hasta 5 es: 15
*/

#include <iostream>

using namespace std;

int main()
{

    cout << "ingrece un numero"<< endl;
    int numero;
    cin >> numero;
    int suma =0;
    int contador = 0;
    while (contador<numero){ // siclo para ir sumando los numeros en determinada rango

        contador = contador + 1; // contador
        suma = (contador + suma); // sumador, va acumulando la suma
}

    if (contador==numero)
        cout << "La sumatoria desde 0 hasta "<<numero <<" es "<< suma << endl;
    return 0;

}
