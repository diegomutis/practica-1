/*
Problema 1.
Escriba un programa que identique si un carácter ingresado es una vocal, una consonante o ninguna de las 2 e imprima un mensaje según el caso.
Nota: el formato de salida debe ser:
no es una letra.
a es una vocal.
C es una consonante.
*/

#include <iostream>

using namespace std;

int main()
{
    cout<<"Ingrece un caracter"<<endl;
    char caracter;
    cin >> caracter;
    char inicio = 'a';

    while (caracter >= inicio ) { // Ciclo para determinar si el caracter ingresado es una letra del alfabeto
        if (caracter==inicio){  // extructura de control para tomar el caracter ingresado y mas adelante saber si es vocal o consonante
            switch (caracter) {  // ciclo para determinar si el caracter ingresado es vocal o consonate
            case 'a':{
                cout <<caracter<<" es una vocal"<<endl;
                break;
            }
            case 'e':{
                cout<<caracter<< " es una vocal"<<endl;
                break;
            }
            case 'i':{
                cout<<caracter<< " es una vocal"<<endl;
                break;
            }
            case 'o':{
                cout << caracter<<" es una vocal"<<endl;
                break;
            }
            case 'u':{
                cout << caracter << " es una vocal"<<endl;
                break;
            }


            default:
                cout << caracter << " es una consonate"<<endl;
                break;

            }

        }
        if (caracter > 'z'){ // control de flujo para determinar que el caracter ingresasado no es una latra del alfaveto
            cout << caracter<<" no es una letra";
        }
        inicio=inicio+1;
    }

    inicio= inicio-1;
     if (caracter<inicio){
    cout<<" No es una letra"<<endl;
    }

    return 0;
}
