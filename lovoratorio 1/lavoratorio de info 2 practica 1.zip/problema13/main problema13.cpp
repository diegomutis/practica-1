/*
Problema 13.
Escriba un programa que reciba un número y calcule la suma de todos los primos menores que el número ingresado.
Ej: Si se recibe 10 el programa debe imprimir 17. Nota:
    la salida del programa debe ser: El resultado de la suma es: 17.
*/

#include <iostream>

using namespace std;

int main()
{
    int numero;
    int suma=0;
    int x = 0;
    int contador=0;
    cout <<"Ingrece un numero"<<endl;
    cin >> numero;
    while (1<numero){ // siclo para buscar los numeros primos
        contador=numero;
        numero=numero-1;
        x=0;
        int n = 1;
        while (1<contador) { // siclo para determinar si un numero es primo
            contador = contador-1;
            if (numero%n==0){
                x=x+1;
                n=n+1;
            }
            else {
                n=n+1;
            }

        }
        if (x==2){

            suma=suma+numero; // suma de los numeros primos
        }

    }
    cout <<"El resultado de la suma es: "<<suma<<endl;

    return 0;
}
