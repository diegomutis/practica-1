/*
Ejercicio 23.
Escriba un programa que pida dos números A y B e imprima en pantalla el mínimo común múltiplo entre los dos.
Ej: si se ingresan 4 y 6 se debe imprimir: El MCM de 4 y 6 es: 12
*/

#include <iostream>

using namespace std;

int main()
{
    int divisor =2; // variable para dividir los numeros
    int m=2;
    int multiplicador = 1;
    int numero;
    int numero1;
    int numero2;
    cout << "ingrce un numero"<<endl;
    cin >> numero1;
    cout<<"Ingrce otro numero"<<endl;
    cin >> numero2;

    int copia1=numero1; // Para guardar el numero original y al final porder imprimirlo en pantalla
    int copia2=numero2; // Para guardar el numero original y al final porder imprimirlo en pantalla

    if (numero1>numero2){  // control de flujo para determinal cual de los numeros ingresados es mayor
        numero=numero1;
    }
    else {
    numero=numero2;
}

    while (numero!=1) {   // siclo para descomponer los numeros ingresados en factores primos

        while (numero1%divisor==0 | numero2%divisor==0) { // siclo para determinar los numeros que si son factores de uno de los dos numeros o de los dos a la vez

        if (numero2%divisor==0) {
            numero2=numero2/divisor; // operacion para ir diviviendo el numero entre sus factores primos
}
        if (numero1%divisor==0) {
            numero1=numero1/divisor;
}
        multiplicador=multiplicador*divisor; // variable para ir acumulando el productos de facores primos
       }
        divisor=(m*2)-1; // para pasar al siguiente numero primo
        numero=numero-1; // funciona como contador para saber en que momento se temina el siclo principal
}

    cout<<"El MCM "<<"de "<<copia1<<" y "<<copia2<<" es: "<<multiplicador<< endl<<endl;

    return 0;
}
