/*
Ejercicio 15.
Escriba un programa que pida constantemente números hasta que se ingrese el número cero e imprima en pantalla la suma de todos los números ingresados.
Ej: si se ingresan 1, 2, 3, 0 se debe imprimir: El resultado de la sumatoria es: 6
*/



#include <iostream>

using namespace std;

int main()
{

    int numero ; //para capturara los numeros que el usuari balla ingresando
    int suma; //para sumar los numeros que el usuario ingrece
    suma = 0;
    cout << "ingrce un mumero"<< endl ;
    cin >> numero;
    while (numero != 0){ //siclo para ir sumando los numeros mientras el usuario no ingrece el cero
        suma =numero+suma;
        cout << "ingrece otro numero"<< endl; // para pedir un numero constante mente
        cin >> numero;
    }

    cout <<"la sumatoria es "<< suma<<endl;

    return 0;
}
