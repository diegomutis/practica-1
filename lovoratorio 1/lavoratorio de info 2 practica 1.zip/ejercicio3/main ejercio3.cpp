/*
Ejercicio 3.
Escriba un programa que pida dos números A y B e imprima en pantalla el mayor.
Ej: si se ingresan 7 y 3 se debe imprimir: El mayor es 7
*/


#include <iostream>

using namespace std;

int main()
{
    int numero1; // variable para guardar
    int numero2;  // los numeros que van hacer comparados

    cout<<"ingrece un numero"<<endl;
    cin >>numero1;
    cout<<"ingrece otro numero"<<endl;
    cin>>numero2;
    if (numero1 > numero2){ //control de flujo para determinar cual de los dos numeros es mayo
        cout <<"El mayor es "<< numero1<<endl;
}
    else (cout <<"El mayor es " <<numero2<<endl);

    return 0;
}
