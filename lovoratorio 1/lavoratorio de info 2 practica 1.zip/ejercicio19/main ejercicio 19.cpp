/*
Ejercicio 19.
Escriba un programa que pida un número N e imprima si es o no un número primo.
Ej: si se ingresa 7 se debe imprimir:
    7 es un numero primo. y si se ingresa 8 se debe imprimir: 8 NO es un numero primo.
*/


#include <iostream>

using namespace std;

int main()
{

    int numero, x,y ;
    x = 1;
    y = 0;
    cout << "Ingrece un numero " << endl;
    cin >> numero;
    while (x <= numero) {  //siclo para determinar cuantos divisores tiene el numero
        if (numero%x==0){  // flujo de control para mira si ese numero es divisor
            x=x+1;
            y=y+1;
            }
        x=x+1; //contador de divisores del numero

    }


    if (y <= 2)
        cout << numero<< " Es un numero primo"<<endl;
    else {
        cout << numero<< " no es un numero primo"<<endl;
    }

    return 0;
}

